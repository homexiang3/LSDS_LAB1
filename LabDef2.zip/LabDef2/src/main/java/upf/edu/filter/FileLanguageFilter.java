package upf.edu.filter;


import upf.edu.parser.SimplifiedTweet;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Optional;
import com.google.gson.Gson;


public class FileLanguageFilter implements LanguageFilter {
	
	private final String inputFile;			  
	private final String outputFile;  		   

	public FileLanguageFilter(String inputFile, String outputFile) {

		 	this.inputFile = inputFile;
		    this.outputFile = outputFile;
		    
	}

	@Override
	public void filterLanguage(String language) throws Exception {
		
		try(BufferedReader bReader = new BufferedReader(new FileReader(this.inputFile));
		    	BufferedWriter bWriter = new BufferedWriter(new FileWriter(this.outputFile));) {
			
			String line = bReader.readLine(); // Read one line of content
			
		while (line != null) {
			
			if (line.contains("created_at")) {
				Optional <SimplifiedTweet> simpTweet = SimplifiedTweet.fromJson(line);
				String tweetlanguage = simpTweet.get().getLanguage();
				
				if(simpTweet.isPresent() && language.equals(tweetlanguage)) {
					bWriter.write(simpTweet.get().toString()+"\n");
				}
			}
			line = bReader.readLine();
        }
        bWriter.close();
        bReader.close();
		}
	}
}