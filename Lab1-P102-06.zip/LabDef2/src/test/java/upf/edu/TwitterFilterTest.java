package upf.edu;

import static org.junit.Assert.*;

import java.util.Optional;

import com.google.gson.Gson;

import upf.edu.parser.SimplifiedTweet;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class TwitterFilterTest
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
    
    @Test
    public void parseValidTweet() {
    	
    	String jsonStr ="{'id':1,'text':'testText','user':{'id':1,'name':'userName'},'lang':'es','timestamp_ms':73891281}";
    	Optional <SimplifiedTweet> simpTweet = SimplifiedTweet.fromJson(jsonStr);
    	boolean test = false;
    	if(simpTweet.isPresent()) {
    		test = true;
    	}
    	assertTrue(test);
    	  	
    }
    
    @Test
    public void parseInvalidTweet() {
    	String jsonStr ="'id':1,'text':'testText','user':{'id':1,'name':'userName'},'lang':'es','timestamp_ms':73891281}";
    	Optional <SimplifiedTweet> simpTweet = SimplifiedTweet.fromJson(jsonStr);
    	boolean test = false;
    	if(simpTweet.isEmpty()) {
    		test = true;
    	}
    	assertTrue(test);
    	  	
    }
    
    @Test
    public void parseValidTweetMissing() {
    	String jsonStr ="{'text':'testText','user':{'id':1,'name':'userName'},'lang':'es','timestamp_ms':73891281}";
    	Optional <SimplifiedTweet> simpTweet = SimplifiedTweet.fromJson(jsonStr);
    	boolean test = false;
    	if(simpTweet.isEmpty()) {
    		test = true;
    	}
    	assertTrue(test);
    	  	
    }

}
