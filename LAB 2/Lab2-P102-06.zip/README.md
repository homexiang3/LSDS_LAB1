## TwitterLanguageFilterApp

Benchmarks exctracted from cluster logs

Benchmark for language "hu":
	- time in seconds = 582 
	
Benchmark for language "es":
	- time in seconds = 626
	
Benchmark for language "pt":
	- time in seconds = 582

## Most popular bi-grams

#### TOP 10 BiGrams es

	(de la,3418)
	(#eurovision #finaleurovision,2934)
	(que no,2412)
	(la canción,2324)
	(de #eurovision,2259)
	(en el,2183)
	(lo que,2024)
	(a la,1838)
	(en la,1823)
	(en #eurovision,1821)
	
#### TOP 10 BiGrams hu

	(viszlát nyár,46)
	(aws -,34)
	(- viszlát,33)
	(- hungary,31)
	(hungary -,31)
	(#eurovisionhun #eurovision,31)
	(- eurovision,30)
	(nyár -,30)
	(eurovision 2018,29)
	(#eurovision #eurovisionhun,28)

#### TOP 10 BiGrams pt

	(a música,254)
	(é que,231)
	(que a,221)
	(#eurovision #allaboard,221)
	(para o,197)
	(o que,175)
	(o ano,175)
	(de israel,141)
	(com a,138)
	(e a,133)




